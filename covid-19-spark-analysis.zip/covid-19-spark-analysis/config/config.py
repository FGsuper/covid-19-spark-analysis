# -*- coding: utf-8 -*-
"""
项目配置文件
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 数据路径
RAW_DATA_PATH = os.path.join(BASE_DIR, 'data', 'covid_data.xlsx')
CLEAN_DATA_PATH = os.path.join(BASE_DIR, 'data', 'covid_data_clean.csv')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

# HDFS路径
HDFS_CLEAN_PATH = 'hdfs://localhost:9000/user/hadoop/covid/clean/'

# Spark配置
SPARK_APP_NAME = 'Covid19SparkAnalysis'
SPARK_MASTER = 'local[*]'
SPARK_CONFIG = {
    'spark.executor.memory': '4g',
    'spark.driver.memory': '2g',
    'spark.sql.shuffle.partitions': '200',
}

# 数据字段
DATA_COLUMNS = ['date', 'province', 'city', 'confirmed', 'deaths', 'recovered', 'suspected']

# 模型参数
DECISION_TREE_PARAMS = {
    'maxDepth': 5,
    'maxBins': 32,
    'minInstancesPerNode': 1,
    'minInfoGain': 0.0,
}

LINEAR_REGRESSION_PARAMS = {
    'maxIter': 100,
    'regParam': 0.1,
    'elasticNetParam': 0.0,
}

# 特征列
FEATURE_COLUMNS = ['day_num', 'month', 'is_weekend', 'province_encoded', 'lag_1', 'lag_7']
LABEL_COLUMN = 'confirmed'
