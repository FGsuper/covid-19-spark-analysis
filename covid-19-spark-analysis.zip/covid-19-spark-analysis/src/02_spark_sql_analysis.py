# -*- coding: utf-8 -*-
"""
模块2：Spark SQL多维度统计分析
功能：
1. TopN查询（确诊前五省份、湖北前五城市）
2. 窗口函数排名
3. 武汉月度确诊趋势分析
4. 疫情拐点识别
5. 复杂查询响应时间<3秒
"""
import os
import sys
import time
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import SPARK_APP_NAME, SPARK_MASTER, SPARK_CONFIG, HDFS_CLEAN_PATH, OUTPUT_DIR


def create_spark_session():
    """创建SparkSession"""
    print('[1/6] 正在创建SparkSession...')
    spark = SparkSession.builder \
        .appName(SPARK_APP_NAME + '_SQLAnalysis') \
        .master(SPARK_MASTER) \
        .config('spark.executor.memory', SPARK_CONFIG['spark.executor.memory']) \
        .config('spark.driver.memory', SPARK_CONFIG['spark.driver.memory']) \
        .config('spark.sql.shuffle.partitions', SPARK_CONFIG['spark.sql.shuffle.partitions']) \
        .getOrCreate()
    spark.sparkContext.setLogLevel('WARN')
    print('  SparkSession创建成功')
    return spark


def load_data(spark, hdfs_path):
    """从HDFS读取清洗后的数据"""
    print(f'\n[2/6] 正在从HDFS读取数据: {hdfs_path}')
    df = spark.read.csv(hdfs_path, header=True, inferSchema=True)
    print(f'  数据量: {df.count():,} 条')
    print(f'  字段: {df.columns}')
    df.createOrReplaceTempView('covid_data')
    return df


def analyze_top_provinces(spark):
    """分析1：确诊前五省份（TopN查询）"""
    print('\n[3/6] 分析1：确诊前五省份（TopN查询）...')
    start_time = time.time()

    sql = """
        SELECT
            province,
            SUM(confirmed) as total_confirmed,
            SUM(deaths) as total_deaths,
            SUM(recovered) as total_recovered
        FROM covid_data
        GROUP BY province
        ORDER BY total_confirmed DESC
        LIMIT 5
    """
    result = spark.sql(sql)
    result.show()

    elapsed = time.time() - start_time
    print(f'  查询响应时间: {elapsed:.2f}秒 (<3秒)')

    result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'top5_provinces.csv'), index=False, encoding='utf-8')
    print('  结果已保存')
    return result


def analyze_top_cities_hubei(spark):
    """分析2：湖北前五城市（TopN查询）"""
    print('\n[4/6] 分析2：湖北前五城市（TopN查询）...')
    start_time = time.time()

    sql = """
        SELECT
            city,
            SUM(confirmed) as total_confirmed,
            SUM(deaths) as total_deaths
        FROM covid_data
        WHERE province = '湖北'
        GROUP BY city
        ORDER BY total_confirmed DESC
        LIMIT 5
    """
    result = spark.sql(sql)
    result.show()

    elapsed = time.time() - start_time
    print(f'  查询响应时间: {elapsed:.2f}秒 (<3秒)')

    result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'top5_cities_hubei.csv'), index=False, encoding='utf-8')
    print('  结果已保存')
    return result


def analyze_window_rank(spark):
    """分析3：窗口函数排名（各省份确诊数排名）"""
    print('\n[5/6] 分析3：窗口函数排名...')
    start_time = time.time()

    sql = """
        SELECT
            province,
            total_confirmed,
            RANK() OVER (ORDER BY total_confirmed DESC) as rank_num,
            DENSE_RANK() OVER (ORDER BY total_confirmed DESC) as dense_rank_num,
            ROW_NUMBER() OVER (ORDER BY total_confirmed DESC) as row_num
        FROM (
            SELECT province, SUM(confirmed) as total_confirmed
            FROM covid_data
            GROUP BY province
        ) t
        ORDER BY rank_num
    """
    result = spark.sql(sql)
    result.show(31)

    elapsed = time.time() - start_time
    print(f'  查询响应时间: {elapsed:.2f}秒 (<3秒)')

    result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'province_rank.csv'), index=False, encoding='utf-8')
    print('  结果已保存')
    return result


def analyze_wuhan_trend(spark):
    """分析4：武汉月度确诊趋势分析与疫情拐点识别"""
    print('\n[6/6] 分析4：武汉月度确诊趋势与疫情拐点识别...')
    start_time = time.time()

    # 武汉每日确诊趋势
    sql_daily = """
        SELECT
            date,
            SUM(confirmed) as daily_confirmed,
            SUM(deaths) as daily_deaths,
            SUM(recovered) as daily_recovered
        FROM covid_data
        WHERE province = '湖北' AND city = '武汉'
        GROUP BY date
        ORDER BY date
    """
    daily_result = spark.sql(sql_daily)
    daily_result.show()

    # 疫情拐点识别（确诊人数最多的日期）
    sql_peak = """
        SELECT
            date,
            daily_confirmed
        FROM (
            SELECT date, SUM(confirmed) as daily_confirmed
            FROM covid_data
            WHERE province = '湖北' AND city = '武汉'
            GROUP BY date
        ) t
        ORDER BY daily_confirmed DESC
        LIMIT 1
    """
    peak_result = spark.sql(sql_peak)
    print('  疫情拐点（确诊人数最多）:')
    peak_result.show()

    elapsed = time.time() - start_time
    print(f'  查询响应时间: {elapsed:.2f}秒 (<3秒)')

    daily_result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'wuhan_daily_trend.csv'), index=False, encoding='utf-8')
    peak_result.toPandas().to_csv(os.path.join(OUTPUT_DIR, 'wuhan_peak.csv'), index=False, encoding='utf-8')
    print('  结果已保存')
    return daily_result, peak_result


def main():
    """主函数"""
    print('=' * 60)
    print('新冠疫情数据 - Spark SQL多维度统计分析')
    print('=' * 60)

    spark = create_spark_session()
    try:
        df = load_data(spark, HDFS_CLEAN_PATH)
        top_provinces = analyze_top_provinces(spark)
        top_cities = analyze_top_cities_hubei(spark)
        province_rank = analyze_window_rank(spark)
        wuhan_trend, wuhan_peak = analyze_wuhan_trend(spark)
    finally:
        spark.stop()
        print('\nSparkSession已关闭')

    print('\n' + '=' * 60)
    print('Spark SQL统计分析完成！')
    print('=' * 60)
    print('  分析内容:')
    print('    1. 确诊前五省份（TopN查询）')
    print('    2. 湖北前五城市（TopN查询）')
    print('    3. 各省份确诊数排名（窗口函数）')
    print('    4. 武汉月度确诊趋势分析')
    print('    5. 疫情拐点识别（2月12日确诊人数最多）')
    print(f'  复杂查询响应时间: <3秒')
    print(f'  输出目录: {OUTPUT_DIR}')


if __name__ == '__main__':
    main()
