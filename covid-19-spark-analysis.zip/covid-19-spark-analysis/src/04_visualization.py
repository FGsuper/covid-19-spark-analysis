# -*- coding: utf-8 -*-
"""
模块4：Matplotlib数据可视化
功能：
1. 湖北前五城市确诊柱状图
2. 武汉每日确诊折线图
3. 疫情趋势与拐点展示
4. 模型对比柱状图
"""
import os
import sys
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.config import OUTPUT_DIR


def load_data():
    """加载分析结果数据"""
    print('[1/5] 正在加载分析结果数据...')
    top_cities = pd.read_csv(os.path.join(OUTPUT_DIR, 'top5_cities_hubei.csv'))
    wuhan_daily = pd.read_csv(os.path.join(OUTPUT_DIR, 'wuhan_daily_trend.csv'))
    wuhan_peak = pd.read_csv(os.path.join(OUTPUT_DIR, 'wuhan_peak.csv'))
    print(f'  湖北城市数据: {len(top_cities)} 条')
    print(f'  武汉每日数据: {len(wuhan_daily)} 条')
    return top_cities, wuhan_daily, wuhan_peak


def plot_top_cities_bar(top_cities):
    """绘制湖北前五城市确诊柱状图"""
    print('\n[2/5] 绘制湖北前五城市确诊柱状图...')
    fig, ax = plt.subplots(figsize=(10, 6))

    cities = top_cities['city'].tolist()
    confirmed = top_cities['total_confirmed'].astype(int).tolist()
    deaths = top_cities['total_deaths'].astype(int).tolist()

    x = range(len(cities))
    width = 0.35

    bars1 = ax.bar([i - width/2 for i in x], confirmed, width, label='确诊人数', color='#E74C3C', alpha=0.8)
    bars2 = ax.bar([i + width/2 for i in x], deaths, width, label='死亡人数', color='#2C3E50', alpha=0.8)

    ax.set_xlabel('城市', fontsize=12)
    ax.set_ylabel('人数', fontsize=12)
    ax.set_title('湖北省前五城市确诊与死亡人数统计', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(cities)
    ax.legend()
    ax.grid(axis='y', alpha=0.3)

    # 添加数值标签
    for bar in bars1:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height):,}', ha='center', va='bottom', fontsize=10)

    plt.tight_layout()
    output_path = os.path.join(OUTPUT_DIR, '01_top5_cities_hubei.png')
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  已保存: {output_path}')


def plot_wuhan_daily_line(wuhan_daily, wuhan_peak):
    """绘制武汉每日确诊折线图（含拐点标注）"""
    print('\n[3/5] 绘制武汉每日确诊折线图...')
    fig, ax = plt.subplots(figsize=(14, 6))

    dates = pd.to_datetime(wuhan_daily['date'])
    confirmed = wuhan_daily['daily_confirmed'].astype(int)
    deaths = wuhan_daily['daily_deaths'].astype(int)
    recovered = wuhan_daily['daily_recovered'].astype(int)

    ax.plot(dates, confirmed, label='确诊人数', color='#E74C3C', linewidth=2, marker='o', markersize=3)
    ax.plot(dates, deaths, label='死亡人数', color='#2C3E50', linewidth=2, marker='s', markersize=3)
    ax.plot(dates, recovered, label='治愈人数', color='#27AE60', linewidth=2, marker='^', markersize=3)

    # 标注疫情拐点
    if len(wuhan_peak) > 0:
        peak_date = pd.to_datetime(wuhan_peak.iloc[0]['date'])
        peak_confirmed = int(wuhan_peak.iloc[0]['daily_confirmed'])
        ax.annotate(f'疫情拐点\n{peak_date.strftime("%Y-%m-%d")}\n确诊{peak_confirmed:,}人',
                    xy=(peak_date, peak_confirmed),
                    xytext=(peak_date + pd.Timedelta(days=5), peak_confirmed * 0.8),
                    arrowprops=dict(facecolor='red', shrink=0.05, width=2),
                    fontsize=11, fontweight='bold', color='red',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.8))

    ax.set_xlabel('日期', fontsize=12)
    ax.set_ylabel('人数', fontsize=12)
    ax.set_title('武汉市每日疫情趋势分析（含拐点识别）', fontsize=14, fontweight='bold')
    ax.legend(loc='upper left')
    ax.grid(alpha=0.3)
    plt.xticks(rotation=45)

    plt.tight_layout()
    output_path = os.path.join(OUTPUT_DIR, '02_wuhan_daily_trend.png')
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  已保存: {output_path}')


def plot_province_rank():
    """绘制各省份确诊数排名柱状图"""
    print('\n[4/5] 绘制各省份确诊数排名柱状图...')
    try:
        province_rank = pd.read_csv(os.path.join(OUTPUT_DIR, 'province_rank.csv'))
        top10 = province_rank.head(10)

        fig, ax = plt.subplots(figsize=(12, 6))
        provinces = top10['province'].tolist()
        confirmed = top10['total_confirmed'].astype(int).tolist()

        colors = plt.cm.Reds([0.3 + 0.07 * i for i in range(len(provinces))])
        bars = ax.barh(provinces[::-1], confirmed[::-1], color=colors, alpha=0.8)

        ax.set_xlabel('累计确诊人数', fontsize=12)
        ax.set_ylabel('省份', fontsize=12)
        ax.set_title('全国各省份累计确诊人数 Top10', fontsize=14, fontweight='bold')
        ax.grid(axis='x', alpha=0.3)

        for bar in bars:
            width = bar.get_width()
            ax.text(width, bar.get_y() + bar.get_height()/2.,
                    f'{int(width):,}', ha='left', va='center', fontsize=10)

        plt.tight_layout()
        output_path = os.path.join(OUTPUT_DIR, '03_province_rank_top10.png')
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f'  已保存: {output_path}')
    except Exception as e:
        print(f'  跳过（数据未生成）: {e}')


def plot_model_comparison():
    """绘制模型对比柱状图"""
    print('\n[5/5] 绘制模型对比柱状图...')
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    models = ['决策树回归', '线性回归']
    r2_scores = [0.46, 0.0]
    rmse_scores = [1500, 5000]  # 示意值

    # R²对比
    bars1 = ax1.bar(models, r2_scores, color=['#3498DB', '#E74C3C'], alpha=0.8, width=0.5)
    ax1.set_ylabel('R² 决定系数', fontsize=12)
    ax1.set_title('模型 R² 对比', fontsize=13, fontweight='bold')
    ax1.set_ylim(0, 0.6)
    ax1.grid(axis='y', alpha=0.3)
    for bar, val in zip(bars1, r2_scores):
        ax1.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.01,
                f'{val:.2f}', ha='center', va='bottom', fontsize=12, fontweight='bold')

    # 结论标注
    ax1.text(0.5, 0.8, '决策树回归更优', transform=ax1.transAxes,
            ha='center', fontsize=12, color='green', fontweight='bold',
            bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.5))

    # RMSE对比（示意）
    bars2 = ax2.bar(models, rmse_scores, color=['#3498DB', '#E74C3C'], alpha=0.8, width=0.5)
    ax2.set_ylabel('RMSE 均方根误差', fontsize=12)
    ax2.set_title('模型 RMSE 对比（示意）', fontsize=13, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)
    for bar, val in zip(bars2, rmse_scores):
        ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 50,
                f'{val:,}', ha='center', va='bottom', fontsize=11)

    plt.suptitle('疫情预测模型对比：决策树回归 vs 线性回归', fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    output_path = os.path.join(OUTPUT_DIR, '04_model_comparison.png')
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  已保存: {output_path}')


def main():
    """主函数"""
    print('=' * 60)
    print('新冠疫情数据 - Matplotlib数据可视化')
    print('=' * 60)

    top_cities, wuhan_daily, wuhan_peak = load_data()
    plot_top_cities_bar(top_cities)
    plot_wuhan_daily_line(wuhan_daily, wuhan_peak)
    plot_province_rank()
    plot_model_comparison()

    print('\n' + '=' * 60)
    print('数据可视化完成！')
    print('=' * 60)
    print('  生成图表:')
    print('    1. 湖北前五城市确诊柱状图')
    print('    2. 武汉每日确诊折线图（含拐点标注）')
    print('    3. 各省份确诊数排名Top10')
    print('    4. 模型对比柱状图')
    print(f'  输出目录: {OUTPUT_DIR}')


if __name__ == '__main__':
    main()
