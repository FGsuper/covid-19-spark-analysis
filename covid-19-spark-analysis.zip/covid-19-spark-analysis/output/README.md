# 输出结果说明

本目录存放各模块运行后的输出结果。

## 文件列表

| 文件名 | 来源模块 | 说明 |
|--------|----------|------|
| top5_provinces.csv | 02_spark_sql_analysis.py | 确诊前五省份统计 |
| top5_cities_hubei.csv | 02_spark_sql_analysis.py | 湖北前五城市统计 |
| province_rank.csv | 02_spark_sql_analysis.py | 各省份确诊数排名（窗口函数） |
| wuhan_daily_trend.csv | 02_spark_sql_analysis.py | 武汉每日确诊趋势 |
| wuhan_peak.csv | 02_spark_sql_analysis.py | 武汉疫情拐点（确诊最多日期） |
| model_comparison.txt | 03_regression_prediction.py | 决策树回归vs线性回归对比结果 |
| 01_top5_cities_hubei.png | 04_visualization.py | 湖北前五城市确诊柱状图 |
| 02_wuhan_daily_trend.png | 04_visualization.py | 武汉每日确诊折线图（含拐点标注） |
| 03_province_rank_top10.png | 04_visualization.py | 各省份确诊数排名Top10 |
| 04_model_comparison.png | 04_visualization.py | 模型对比柱状图 |

## 注意

- 运行各模块后会自动生成对应文件
- CSV文件使用UTF-8编码
- PNG图片分辨率150dpi
